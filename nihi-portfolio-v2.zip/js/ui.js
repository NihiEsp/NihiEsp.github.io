/* ============================================================
   ui.js
   Owns: theme toggle (toggleTheme), tab title typewriter effect
   Depends on: shader.js (window.shaderThemeTarget)
   ============================================================ */

/* ── Theme toggle ────────────────────────────────────────── */
function toggleTheme() {
  const html  = document.documentElement;
  const isDark = html.getAttribute('data-theme') === 'dark';
  html.setAttribute('data-theme', isDark ? 'light' : 'dark');
  // Tell the background shader which direction to animate toward
  window.shaderThemeTarget = isDark ? 1.0 : 0.0;
}


/* ── Tab title typewriter ────────────────────────────────── */
const TAB_PHRASES = [
  'nihi ✦',
  'i make things.',
  'gmt+1',
];

let tabPhrase = 0;
let tabChar   = 0;
let tabDir    = 1;

const TAB_TYPE_MS  = 80;
const TAB_ERASE_MS = 44;
const TAB_HOLD_MS  = 2400;
const CURSOR       = '▌';

function tickTab() {
  const phrase = TAB_PHRASES[tabPhrase];
  if (tabDir === 1) {
    tabChar = Math.min(tabChar + 1, phrase.length);
    document.title = phrase.slice(0, tabChar) + (tabChar < phrase.length ? CURSOR : '');
    if (tabChar >= phrase.length) {
      tabDir = -1;
      setTimeout(tickTab, TAB_HOLD_MS);
    } else {
      setTimeout(tickTab, TAB_TYPE_MS);
    }
  } else {
    tabChar = Math.max(tabChar - 1, 0);
    document.title = phrase.slice(0, tabChar) + (tabChar > 0 ? CURSOR : '');
    if (tabChar <= 0) {
      tabPhrase = (tabPhrase + 1) % TAB_PHRASES.length;
      tabDir = 1;
      setTimeout(tickTab, 380);
    } else {
      setTimeout(tickTab, TAB_ERASE_MS);
    }
  }
}

// Start after a short delay so the enter screen is visible first
setTimeout(tickTab, 1500);
